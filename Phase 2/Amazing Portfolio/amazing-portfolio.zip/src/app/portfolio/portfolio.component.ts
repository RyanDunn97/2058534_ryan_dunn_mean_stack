import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact.module';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css']
})
export class PortfolioComponent implements OnInit {
  contactList:Array<Contact>=[];

  loginRef = new FormGroup({
    user:new FormControl(),
    pass:new FormControl()
  });

  regRef = new FormGroup({
    user:new FormControl(),
    pass:new FormControl()
  });

  contactRef = new FormGroup({
    name:new FormControl(),
    phoneNo:new FormControl()
  });

  loginPage:boolean = true;
  registrationPage:boolean = false;
  portfolioPage:boolean = false;

  username:string = "ryan";
  password:string = "123";

  msg:string ="";
  regMsg:string="";
  contactMsg:string="";

  constructor() { }

  ngOnInit(): void {
  }

  // check if login info matches
  checkLogin():void{
    let login = this.loginRef.value;
    if(login.user==this.username && login.pass==this.password)
    {
      // switch to portfolio page
      this.switchPage(2);
    }
    else{
      // change msg to failed
      this.msg = "Invalid username or password.";
    }
  }

  // register user by setting username and pass
  registerUser():void{
    // take info from form
    let reg = this.regRef.value;
    // set username and password and switch page
    if(reg.user != null && reg.pass != null)
    {
      this.username = reg.user;
      this.password = reg.pass;
      this.switchPage(0);
    }
    else{
      this.regMsg = "Invalid. Enter values in user and pass.";
    }
  }

  // create contact object, push it to array
  addToContacts():void{
    let con = this.contactRef.value;
    if(con.name != null && con.phoneNo != null){
      // create contact object
      let newContact:Contact = {contactName:con.name,phoneNo:con.phoneNo};
      // push it to array
      this.contactList.push(newContact);
    }
    else{
      this.contactMsg ="Invalid. Enter values in both fields.";
    }
    
  }

  // 0=login,1=reg,2=port
  switchPage(pageInput:number):void{
    // takes input, switches div's to get the page requested
    if(pageInput==0)
    {
      this.loginPage = true;
      this.registrationPage = false;
      this.portfolioPage = false;
    }
    else if(pageInput == 1)
    {
      this.loginPage = false;
      this.registrationPage = true;
      this.portfolioPage = false;
    }
    else if(pageInput == 2)
    {
      this.loginPage = false;
      this.registrationPage = false;
      this.portfolioPage = true;
    }
  }

}
