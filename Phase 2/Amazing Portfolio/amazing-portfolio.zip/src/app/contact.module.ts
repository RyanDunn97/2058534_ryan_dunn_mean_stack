export interface Contact{
    contactName:string;
    phoneNo:number;
}