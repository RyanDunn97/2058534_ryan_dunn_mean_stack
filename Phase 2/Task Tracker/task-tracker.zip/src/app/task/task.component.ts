import { Component, OnInit } from '@angular/core';
import { Task } from '../task.module';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  contactRef = new FormGroup({
    empId:new FormControl(),
    name:new FormControl(),
    task:new FormControl(),
    deadline:new FormControl()
  });

  taskList:Array<Task>=[];


  constructor() { }

  ngOnInit(): void {
  }

  saveTask():void{
    let inputTask = this.contactRef.value;
    let newTask:Task  = {empId:inputTask.empId,name:inputTask.name,
      task:inputTask.task,deadline:inputTask.deadline};
    this.taskList.push(newTask);
  }
}
