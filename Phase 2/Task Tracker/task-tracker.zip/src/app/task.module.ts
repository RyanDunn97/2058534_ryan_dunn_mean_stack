export interface Task{
    empId:number,
    name:string,
    task:string,
    deadline:string
}