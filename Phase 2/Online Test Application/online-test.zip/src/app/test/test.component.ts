import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { QuestionsService } from '../questions.service';
import { Questions } from '../questions.model';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  myForm:FormGroup;
  // array 
  allQuestions:Array<Questions>=[];

  constructor(public form:FormBuilder, public questionSer:QuestionsService) {
    this.myForm=form.group({});
   }

  ngOnInit(): void {
    
    this.questionSer.loadQuestions().subscribe(request => this.allQuestions = request);
    console.log(this.allQuestions);
    console.log(this.allQuestions[0].question);
    // add form control to the questions
    
  }

  // function used upon submit of quiz
  submit():void{
    console.log("quiz submitted");
    console.log(this.myForm);
  }

  
}
