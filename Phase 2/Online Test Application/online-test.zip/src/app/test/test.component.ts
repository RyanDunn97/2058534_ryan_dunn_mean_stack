import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { QuestionsService } from '../questions.service';
import { Questions } from '../questions.model';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  myForm:FormGroup;
  // array 
  public allQuestions:Array<Questions>=[];
  public correctAnswers:Array<any>=[];
  msg:string="";

  constructor(public form:FormBuilder, public questionSer:QuestionsService) {
    this.myForm=form.group({});
   }


  ngOnInit(): void {
    
    this.questionSer.loadQuestions().subscribe(request => {
      for(let q of request){
        this.myForm.addControl(q.question,this.form.control(""));
        this.allQuestions.push(q);
        this.correctAnswers.push(q.correctAns);
      }
    });
  }

  // calculates exam score and manipulates page elements
  submit():void{
    let numCorrect:number = 0;
    let iteration = 0;
    let resElem:any = document.getElementById("results");

    // change styling based on answers
    Object.keys(this.myForm.value).forEach(key=>{
      let curElem:any = document.getElementById(this.myForm.value[key]);
      if(this.myForm.value[key] == this.correctAnswers[iteration])
      {
        numCorrect++;
        curElem.style.color ='green';
        curElem.style.backgroundColor = 'lightgreen';
        curElem.innerHTML += ' CORRECT!';
      }
      else{
        curElem.style.color = 'red';
        curElem.style.backgroundColor = 'lightred';
        curElem.innerHTML += ' INCORRECT';
      }
      iteration++;
    });
    console.log(this.myForm.value);
    
    // check if they passed
    if (numCorrect > 6)
    {
      this.msg = "Congratulations. You passed! Result: " + numCorrect + "/10.";
      resElem.style.color = 'green';
    }
    else{
      this.msg = "Result: " + numCorrect + "/10: Fail.";
      resElem.style.color = 'red';
    }
  }

  
}
