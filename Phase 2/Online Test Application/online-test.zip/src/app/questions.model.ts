export interface Questions{
    question:string,
    ans1:string,
    ans2:string,
    ans3:string,
    ans4:string,
    corrrectAns:string
}